import UIKit

var greeting = "Hello, playground"
print("Hii",10,12.25)
print(greeting)
//string
var programmingLanguage = "Swift"
print("My favorite programming language is \(programmingLanguage)")
var name="Lavanya"
print("Hello, \(name)!")
var grade="A"
print("Hello, \(name)! You got the \(grade) in iOS Course.")
var grade1=90
print("Hello, \(name)! You got the \(grade1) percent in iOS Course.")
var age=24
print("your current age is \(age) and when your tripled, you will be \(age*3)")
print("""
Hello
World!
""")
//r is carriage means return
print ("Hello All,\rWelcome to Swift programming")
//let is constant explicit delcaration of datatype
let  welcomeMessage : String = "Hello!"
   print(welcomeMessage , "All")
//print on same line
print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
//terminator always takes string and terminates the next print statmnet and allows u to print in same line
print("Welcome to Swift Programming" , terminator : "-" )
print("Spring 2022")

var name1="Lavanya Peddinti"
var grade2=92
print("Hello, \(name1)!", terminator: "-")
print("You got \(grade2) percent in iOS course.")

print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is", terminator: ":")
print(1,2,3,4,5,6, separator: "-")
//var and constant
var mobileBrand = "Good day"
mobileBrand = "Good morning"
print(mobileBrand)

 let pi = 3.14
//pi=2.16 cannot assign to value pi because let is a costant and cannot be alerted
print(pi)

var age3 : Int = 23 //UML declaration
age3 = age3 * 2
print(age3)

var aMessage = "This is Superb!"
print(aMessage)
print("aMessage")

var course1 = "iOS"
var course2 = "Java"
print(course1,course2) // , is replaced with space
print(course1,"-",course2)

print(10,20,30)
print(12.5,15.5)

//tuples: decelaring values in () is know as tuple
var httpError  = (errorCode : 404  , errorMessage : "Page Not Found")
print(httpError)
//print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )

var names = ("Lavanya","Peddinti")
var fName = names.0
var lName = names.1
print(fName , terminator : ",")
print(lName)

var origin = (a : 100 , b : 100)
var point = origin
print(point)

let city = (name : "Maryville" , population : 11,000)
let ( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)

let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(groceries)
print(type(of: groceries))

var fname = "Lavanya"
var lname = "Peddinti"
(fname , lname) = (lname , fname)
print("First Name is \(fname) and Last Name is \(lname)")

var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
